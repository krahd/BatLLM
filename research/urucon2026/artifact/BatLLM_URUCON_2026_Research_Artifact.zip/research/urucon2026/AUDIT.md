# Final adversarial audit

## Verdict

The canonical paper is defensible as a narrow systems contribution: an evidence contract that connects an application-level LLM invocation and retained response to explicit grounding and deterministic state/event replay. It is not defensible as generic agent provenance, model-output reproducibility, transport capture, or authenticated chain of custody.

The authoritative manuscript and its writing audits are maintained in `krahd/academic-writing`; this repository contains the implementation and reproducibility evidence.

## Novelty boundary

The following claims remain prohibited:

- first provenance model for LLM agents;
- first record-and-replay system for agents;
- first trace contract for language-to-action systems;
- first forensic replay of prompt–response interactions;
- first use of games to evaluate or teach LLM interaction.

PROV-AGENT, AgentRR, Prompt Scene Investigation, `agrepl`, Message–Action Trace contracts, W3C PROV, OpenTelemetry, and the 2026 survey of evidence tracing and execution provenance establish substantial prior art. The contribution survives because its verification object is the conjunction:

```text
human instruction and context
→ application-level adapter invocation
→ retained response or commitment
→ explicit response-to-command grounding
→ frozen domain transition
→ recorded state and semantic events
```

## Implementation findings

- Recorder and verifier use the production BatLLM parser and transition engine.
- Full-retention invocation verification reconstructs the current message and conversation history from separately recorded fields rather than trusting a self-hash alone.
- Invocation errors are represented separately and are not counted as model groundings.
- Raw model text is excluded from semantic events after an earlier privacy leak was found and fixed.
- Retention-dependent guarantees are explicit.
- The independent reference semantics imports no production gameplay module.
- Fault injection re-anchors retained-content commitments and targets multiple trace positions.
- Benign serialisation controls test false rejection.
- Before migration, the canonical manuscript compiled to four A4 IEEE pages without overfull boxes, undefined citations, or embedded hyperlinks; the exact Word manuscript is now preserved in `academic-writing` with its source hash.

## Residual limitations

- v3 remains a headless research path; the GUI exports v2.
- The adapter record is not a wire capture.
- Requested model identity is declarative, not cryptographically bound to weights or serving binaries.
- Retry count is recorded, but successful-after-retry traces do not preserve every intermediate provider error.
- Scripted responses validate trace semantics rather than live-model behaviour.
- Reference and production semantics can share a specification error.
- Hash commitments are neither signatures nor confidentiality mechanisms.
- Reduced retention cannot independently verify response grounding.
- Transfer beyond BatLLM is architectural, not empirically demonstrated.

## Release criterion

The software research artefact is complete only when:

1. all nine OS/Python research matrix jobs pass;
2. repository dependency and multiplatform workflows pass;
3. the full experiment suite regenerates all summaries;
4. generated metrics agree with the canonical manuscript;
5. the packaged artefact contains implementation evidence but no manuscript duplicate; and
6. the final PR diff contains no corrupted or unrelated file.

## Final hardening pass

The final adversarial pass corrected additional defects that were not exposed by the initial deterministic corpus: permissive command-prefix parsing, acceptance of non-finite numeric commands, loss of response whitespace, a zero-length projectile-segment division, ambiguity when full text literally equalled the redaction marker, unsafe stringification of unknown event objects, canonical key collisions, incomplete cross-round continuity checks, and verifier exceptions on non-canonical values. Regression tests now cover each case. Public claims were also narrowed from an object purportedly passed wholesale to a provider adapter to an adapter-boundary record whose call-argument and declarative fields are distinguished explicitly.
